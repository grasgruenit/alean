---
title: 'Ihr Partner für unabhängige Vermögensverwaltung aus Liechtenstein.'
image: 
---
Die Alean (Capital) AG ist eine unabhängige Vermögensverwaltungsgesellschaft mit einer langjährigen Erfolgsgeschichte. 2007 in Liechtenstein gegründet und seit 2010 von der FMA (Finanzmarktaufsicht Liechtenstein) lizenziert, sind wir auch in Deutschland, Italien, Österreich und Spanien zugelassen.

Unser erfahrenes Team aus Investmentspezialisten bietet Ihnen eine transparente und effiziente Vermögensverwaltung.

Als Mitglied des Vereins unabhängiger Vermögensverwalter in Liechtenstein (VuVL) sind wir dem Anlegerschutzsystem der Einlagensicherungs- und Anlegerentschädigungs-Stiftung SV angeschlossen, das dem EU-Recht entspricht. Weitere Informationen finden Sie unter www.eas-liechtenstein.li.